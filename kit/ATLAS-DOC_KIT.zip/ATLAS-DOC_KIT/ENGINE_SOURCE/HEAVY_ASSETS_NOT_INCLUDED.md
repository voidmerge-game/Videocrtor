# Heavy assets not included in this zip (download/regenerate)
- public/data/earth_region.jpg, earth_world.jpg, bump_region.jpg, bump_world.jpg, clouds_africa.png, clouds_world.png, night_world.jpg  -> regenerate with scripts/make_earth_v6.py (sources in kit file 02 §F) or pull from the GitHub repo voidmerge-game/Videocrtor (main).
- public/audio/music/*.mp3 -> Kevin MacLeod, incompetech.com (kit file 04 §3)
- public/audio/sfx/*.wav   -> scripts/make_sfx.py (kit file 05 §6)
- public/audio/vo/p/*.mp3  -> regenerate per episode (kit file 02 §C); paragraphs.json of the reference film is included for structure.
- public/archive/*.jpg, public/archive/clips/*.mp4|jpg -> Wikimedia Commons, see public/archive/credits.json
Everything above exists in the GitHub repo (commit b58427c / f475c45).
