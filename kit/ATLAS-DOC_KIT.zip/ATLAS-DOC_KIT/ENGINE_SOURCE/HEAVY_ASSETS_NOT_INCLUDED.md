# Heavy assets NOT included in this zip — regenerate them in YOUR new repo (no access to the original repo is needed)
| path | how to (re)create |
|---|---|
| public/data/earth_region.jpg, earth_world.jpg, bump_region.jpg, bump_world.jpg, clouds_africa.png, clouds_world.png, night_world.jpg | `scripts/make_earth_v6.py` — sources & parameters in kit file 02 §F. Run on GitHub Actions (ubuntu-latest) or locally with memmap; set REGION for the new episode. |
| public/audio/music/*.mp3 | Kevin MacLeod, incompetech.com (CC BY 4.0) — kit file 04 §3 |
| public/audio/sfx/*.wav | `python3 scripts/make_sfx.py` — code in kit file 05 §6 |
| public/audio/vo/p/*.mp3 | regenerate per episode with generate_speech — kit file 02 §C |
| public/archive/*.jpg, public/archive/clips/*.mp4 + poster .jpg | Wikimedia Commons PD/CC0 — kit file 02 §G |
Everything else needed to build and render is in this folder.
