# ATLAS-DOC Production Kit — ابدأ من هنا
1. `00-07_KIT/` — الحقيبة (اقرأ 00 أولاً — وفيه بروتوكول استلام توكن GitHub عبر المحادثة وحفظه بـ bash — ثم 01→07، ثم README_HANDOVER).
2. `ENGINE_SOURCE/` — كود المحرك الكامل؛ يُزرع في مستودع GitHub جديد فارغ (تنشئه أنت بالتوكن عبر API إن لزم). الأصول الثقيلة: HEAVY_ASSETS_NOT_INCLUDED.md.
3. `KIT_FACTORY_SOURCE/` — مطالبات المصنع الأصلية (00–05).
لا يلزم أي "موصل GitHub": كل شيء يتم بـ bash + curl + git.
