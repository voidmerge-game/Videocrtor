# ATLAS-DOC Production Kit — ابدأ من هنا
1. `00-07_KIT/` — الحقيبة (اقرأ 00 أولاً ثم 01→07، ثم README_HANDOVER).
2. `ENGINE_SOURCE/` — كود المحرك الكامل (Remotion + سكربتات + workflows + بيانات الحدود + الخطوط + paragraphs.json المرجعي). الأصول الثقيلة مذكورة في HEAVY_ASSETS_NOT_INCLUDED.md.
3. `KIT_FACTORY_SOURCE/` — مطالبات المصنع الأصلية (00–05) التي بُنيت الحقيبة وفقها؛ الملف 05 هو ما يُعطى للنموذج الثالث.
المرجع الحي: https://github.com/voidmerge-game/Videocrtor
