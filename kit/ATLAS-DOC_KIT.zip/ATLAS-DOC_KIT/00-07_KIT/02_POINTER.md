# 02 — دليل الأدوات وإعداداتها الدقيقة (ملف إحالة)

لم يسمح موصل Google Drive برفع هذا الملف من داخل الجلسة (فلتر أمني لدى مزوّد الموصل يلتقط أنماط أوامر التوثيق مثل `Authorization: Bearer` و`x-access-token` الموجودة في أمثلة الأوامر). المحتوى سليم ولا يحتوي أي توكن حقيقي.

النسخة الكاملة (13.8 KB) موجودة في المستودع:

- صفحة: https://github.com/voidmerge-game/Videocrtor/blob/main/kit/02_TOOLS_AND_EXACT_PARAMETERS_%D8%AF%D9%84%D9%8A%D9%84_%D8%A7%D9%84%D8%A3%D8%AF%D9%88%D8%A7%D8%AA_%D9%88%D8%A5%D8%B9%D8%AF%D8%A7%D8%AF%D8%A7%D8%AA%D9%87%D8%A7_%D8%A7%D9%84%D8%AF%D9%82%D9%8A%D9%82%D8%A9.md
- تنزيل مباشر (raw): https://raw.githubusercontent.com/voidmerge-game/Videocrtor/main/kit/02_TOOLS_AND_EXACT_PARAMETERS_%D8%AF%D9%84%D9%8A%D9%84_%D8%A7%D9%84%D8%A3%D8%AF%D9%88%D8%A7%D8%AA_%D9%88%D8%A5%D8%B9%D8%AF%D8%A7%D8%AA%D9%87%D8%A7_%D8%A7%D9%84%D8%AF%D9%82%D9%8A%D9%82%D8%A9.md

نزّله وضعه في هذا المجلد يدوياً لتكتمل الحقيبة (00 → 07) في Drive.
